package lu.ankang.ignitedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IgnitedemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
